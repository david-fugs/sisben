<?php
	
	$mysqli = new mysqli("localhost", "aprendad_sisben", "~CY]&J9u#wxa", "aprendad_sisben");
	
?>
